<?php
	include 'bdd.php';

    if (isset($_GET['aloID'])) {
        $aloID = $_GET['aloID'];
    }

    $query = "DELETE FROM shift_attendance WHERE aloID= :aloID";
    $query = $bdd->prepare($query);

    $query->execute(['aloID' => $aloID]);

     header("Location: viewShiftAttendance.php");
?>
