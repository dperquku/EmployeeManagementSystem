<?php
	include 'bdd.php';

    if (isset($_GET['empID'])) {
        $empID = $_GET['empID'];
    }
     $query1 = "SELECT * FROM employee WHERE empID= :empID";
    $query1 = $bdd->prepare($query1);

    $query1->execute(['empID' => $empID]);

    $result=$query1->fetch();

    $query2 = "UPDATE login set currentStatus=0 WHERE username='".$result['username']."'";
    $query2 = $bdd->prepare($query2);
    $query2->execute();

    $query = "UPDATE employee set currentStatus=0 WHERE empID= :empID";
    $query = $bdd->prepare($query);

    $query->execute(['empID' => $empID]);


   
    


     header("Location: viewEmployee.php");
?>
