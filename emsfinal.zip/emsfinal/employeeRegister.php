<?php
include('session.php');
require('include/connect.php');

$sql = "SELECT departmentName ,departmentId FROM department";
$con = mysqli_connect("localhost", "root", "", "ems");
$result = mysqli_query($con,$sql);





                                            if(isset($_POST['submit'])){
                                    
                                               
                                              
                                              $empFirstName = $_REQUEST['empFirstName'];
                                              if (!preg_match("/^[a-zA-Z ]*$/",$empFirstName)) {
                                                $nameErr = "Only letters and white space allowed"; 
                                                }   
                                              $empLastName = $_REQUEST['empLastName'];
                                              $empNO = $_REQUEST['empNO'];
                                                $empemail = $_REQUEST['empemail'];
                                                $empMobile = $_REQUEST['empMobile'];
                                                $empbdate = $_REQUEST['empbdate'];
                                                $empaddress = $_REQUEST['empaddress'];
                                                $depEmpId = $_REQUEST['depEmpId'];
                                                $username = $_REQUEST['username'];
                                                $password = $_REQUEST['password'];

                                               
                                                                                                  
                                                 
                                                $sql = 'INSERT INTO employee (empFirstName, empLastName,  empNO,empemail,empMobile,empbdate,empaddress,depEmpId,username,password) VALUES (:empFirstName, :empLastName, :empNO,:empemail,:empMobile,:empbdate,:empaddress,:depEmpId,:username,:password)';
                                                

                                                $query = $conn->prepare($sql);
                                                $query->bindParam('empFirstName', $empFirstName);
                                                $query->bindParam('empLastName', $empLastName);
                                                $query->bindParam('empNO', $empNO);
                                                 $query->bindParam('empemail', $empemail);
                                                 $query->bindParam('empMobile', $empMobile);
                                                 $query->bindParam('empbdate', $empbdate);
                                                 $query->bindParam('empaddress', $empaddress);
                                                 $query->bindParam('depEmpId', $depEmpId);
                                                 $query->bindParam('username', $username);
                                                 $query->bindParam('password', $password);
                                            
                                            
                                                 $sql1='INSERT INTO login (name ,email, username,phone,password, is_admin) VALUES (:empFirstName, :empemail,:username, :empMobile, :password,0)';
                                                 $query1 = $conn->prepare($sql1);

                                                 $query1->bindParam('empFirstName', $empFirstName);
                                                
                                                 $query1->bindParam('empemail', $empemail);
                                                 $query1->bindParam('username', $username);
                                                 $query1->bindParam('empMobile', $empMobile);
                                               $query1->bindParam('password', $password);
                                                
                                                   
                                            
                                                if($query->execute() && $query1->execute()) {
                                                $message = "Thank You for your Feedback!  ";
                                                    echo "$message";
                                                     header("Location: viewEmployee.php");
                                            } else {
                                                $message = "A problem occurred creating your account";
                                                 echo "$message";
                                            }
                                                
                                                
                                               
                                            }   
                                                                         


?>

<!DOCTYPE HTML>
<html>
<head>
<title>Employe Management System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Gretong Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
<link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />

<!-- //lined-icons -->
<link rel="stylesheet" href="css/emp.css" />
<link rel="stylesheet" href="css/style1234.css" />
   
</head> 
<body>
   <div class="page-container">
   <!--/content-inner-->
	<div class="left-content">
	   <div class="inner-content">
		<!-- header-starts -->
			<div class="header-section">
      <!-- top_bg -->
            <div class="top_bg">
             <ul class="nav navbar-right navbar-top-links">
                 
      </li>
            <li class="dropdown" style="padding-right: 10px;padding-top:4px; ">

                <a class="dropdown-toggle" data-toggle="dropdown" href="#" style="color: white;">


                    <i class="fa fa-user fa-fw" style="color:white; "></i>Welcome : <i><?php echo $login_session; ?></i>
                </a>
               
                
            </li>
        </ul>
             
                <div class="header_top">
                  

                    
                  </div>
                    <div class="clearfix">

                     
                 </div>


                </div>
              
            </div>
					<div class="clearfix"></div>
				<!-- /top_bg -->
				</div>
				
				
				<!--content-->
			<div class="content">
			<div>
<h1 ><i class="menu-icon fa fa-pencil" style="padding-right: 10px; padding-left: 20px;"></i>Employee Register</h1></div>
 
<div class="employee" >


      <div class="empReg">
    <form action="employeeRegister.php" method="POST" style="margin-right:60px;" name="emp"  onsubmit="return validateForm();" >
      <div class="col-sm-3">
         
          <div class="inputi">
            <label for="empNO">Personal Number <span class="req">*</span> </label>
            <input type="text" name="empNO"  />      
          </div>
          <div class="inputi">
            <label for="empFirstName">First Name <span class="req">*</span> </label>
            <input type="text" name="empFirstName"  />      
          </div>
           <div class="inputi">
            <label for="empLastName">Last Name <span class="req">*</span> </label>
            <input type="text" name="empLastName"  />      
          </div>
           <div class="inputi">
            <label for="empemail">Email <span class="req">*</span> </label>
            <input type="text" name="empemail"  />      
          </div>
          

          <input class="btn btn-submit" type="submit" name="submit" value="Save" style="margin-top: 10px;" />
          <input class="btn btn-reset" type="reset" name="reset" value="Reset" style="margin-top: 10px;" />
      </div>
   <div class="col-sm-3">
         
         <div class="inputi1" style="">
            <label for="username">Username <span class="req">*</span> </label>
            <input type="text" name="username"  />      
          </div>
          <div class="inputi">
            <label for="password">Password <span class="req">*</span> </label>
            <input type="password" name="password"  />      
          </div>
           <div class="inputi">
            <label for="empbdate">Date of Birth <span class="req">*</span> </label>
            <input type="date" name="empbdate" style="width: 205px; height: 40px;"  />      
          </div>
           <div class="inputi">
            <label for="empMobile">Phone Number <span class="req">*</span> </label>
            <input type="text" name="empMobile"  />      
          </div>
          

      </div>
         <div class="col-sm-3">
         
         
          <div class="inputi">
            <label for="empaddress">Address<span class="req">*</span> </label>
            <input type="text" name="empaddress"  />      
          </div>
          <div class="inputi1">
                 <label for="department" style="padding-top: 10px; ">Department<span class="req">*</span> </label>
              <?php  echo "<select name='depEmpId' style='padding-right:40px; width:205px; height:40px; border: 1px solid #ccc;color: #555;' required >";
                echo "<option > Select Department:</option>"; 
        while ($row = mysqli_fetch_array($result)) {
          echo "<option value='" . $row['departmentId'] ."'>" . $row['departmentName'] ."</option>";
        }
        echo "</select>"; ?>      
          </div>
      </div>
        
      
        
      
     
    </form> 
  </div>
		 <script>
                function isNumeric(n) {
  return !isNaN(parseFloat(n)) && isFinite(n);
  }
function validateForm() {
  var b = document.forms["emp"]["empNO"].value;
     if(b.length!=10) {
       
        alert("Your personal number should contain 10 numbers!");
        return false;
    }
    var x = document.forms["emp"]["empFirstName"].value;
    if (isNumeric(x)) {
        alert("Your First Name should not contain numbers!");
        return false;
    }

    var a = document.forms["emp"]["empLastName"].value;
    if (isNumeric(x)) {
        alert("Your Last Name should not contain numbers!");
        return false;
    }
      var y = document.forms["emp"]["empemail"].value;
    var atpos = y.indexOf("@");
    var dotpos = y.lastIndexOf(".");
   if (atpos<1 || dotpos<atpos+2|| dotpos+2>=y.length ) {
        alert(" E-mail address it's not valid!");
        return false;
    }
    var q = document.forms["emp"]["username"].value;
    if (q.length<= 3) {
        alert("Your Username should be longer than 3 characters!");
        return false;
    }

     var w = document.forms["emp"]["password"].value;
     if(w.length<8) {
       
        alert("Your password should contain at least 8 characters!");
        return false;
    }
       
     
}
   
                                 
            </script>
   </div>
  </div>
		
			<!--content-->
		</div>
</div>
				<!--//content-inner-->
			<!--/sidebar-menu-->
				<div class="sidebar-menu">
					<?php include 'include/slider.php'; ?>
							  </div>
							  <div class="clearfix"></div>		
							</div>
							<script>
							var toggle = true;
										
							$(".sidebar-icon").click(function() {                
							  if (toggle)
							  {
								$(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
								$("#menu span").css({"position":"absolute"});
							  }
							  else
							  {
								$(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
								setTimeout(function() {
								  $("#menu span").css({"position":"relative"});
								}, 400);
							  }
											
											toggle = !toggle;
										});
							</script>
<!--js -->


<!-- Bootstrap Core JavaScript -->
 
   <!-- /Bootstrap Core JavaScript -->
   <!-- real-time -->

		   

 <!-- time picker -->
        <script src="http://code.jquery.com/jquery-1.12.4.min.js"></script>
        
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    	<link rel="stylesheet" href="css/clockface.css">    
        <script src="js/clockface.js"></script>

<script id="js-t1">
$(function(){
    $('#t1').clockface();
    $('#t2').clockface();  
});
</script>

</body>
</html>