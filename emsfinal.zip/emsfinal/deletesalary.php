<?php
	include 'bdd.php';

    if (isset($_GET['salID'])) {
        $salID = $_GET['salID'];
    }

    $query = "DELETE FROM salary WHERE salID= :salID";
    $query = $bdd->prepare($query);

    $query->execute(['salID' => $salID]);

     header("Location: viewSalary.php");
?>
