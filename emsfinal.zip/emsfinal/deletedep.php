<?php
	include 'bdd.php';

    if (isset($_GET['departmentId'])) {
        $departmentId = $_GET['departmentId'];
    }

    $query = "DELETE FROM department WHERE departmentId= :departmentId";
    $query = $bdd->prepare($query);

    $query->execute(['departmentId' => $departmentId]);

     header("Location: viewDepartment.php");
?>
