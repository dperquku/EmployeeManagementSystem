<?php   include'../bdd.php';
		
		$id="SELECT empID from employee WHERE username='$user_check'";
		$my=$bdd->prepare($id);
		$my->execute();
		$user=$my->fetch();


?>

<header class="logo1">
						<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
						<a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> 
					</header>
						<div style="border-top:1px ridge rgba(255, 255, 255, 0.15)"></div>
                           <div class="menu">
									<ul id="menu" >
										<li><a href="empindex.php"><i class="fa fa-tachometer"></i> <span>Dashboard</span></a></li>
										<li><a href="employeeprofil.php?empID=<?php echo $user['empID']; ?>"><i class="fa fa-user"></i> <span>Your Profile</span></a></li>
										
										
											
										<li><a href="inbox.php"><i class="fa fa-envelope"></i> <span>Inbox</span></a></li>
										<li><a href="calendar.php"><i class="fa fa-calendar"></i> <span>Calendar</span></a></li>
										<li><a href="logout.php" ><i class="fa fa-sign-out fa-fw" ></i><span> Logout</span></a></li>
										 
								  </ul>
								</div>