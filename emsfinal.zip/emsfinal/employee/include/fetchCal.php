<?php

if(isset($_POST['view'])){
 $con = mysqli_connect("localhost", "root", "", "ems");
if($_POST["view"] != '')
{
    $update_query = "UPDATE attendance SET status = 1 WHERE status=0";
    mysqli_query($con, $update_query);
    $update_query1 = "UPDATE holiday SET status = 1 WHERE status=0";
    mysqli_query($con, $update_query1);
    $update_query2 = "UPDATE shift_allocation SET status = 1 WHERE status=0";
    mysqli_query($con, $update_query2);
    $update_query3 = "UPDATE shift_attendance SET status = 1 WHERE status=0";
    mysqli_query($con, $update_query3);
}
$query = "SELECT * FROM attendance,holiday,shift_allocation,shift_attendance";
$result = mysqli_query($con, $query);
$output = '';
if(mysqli_num_rows($result) > 0)
{
 while($row = mysqli_fetch_array($result))
 {
   $output .= '
   <li>
   <a href="calendar.php"><strong>New event:</strong><br />
   <small><em>has been added </em></small>
   </a>
   </li>
   ';
 }
}
else{
     $output .= '
     <li><a href="#" class="text-bold text-italic">No Noti Found</a></li>';
}
$status_query = "SELECT * FROM attendance,holiday,shift_allocation,shift_attendance WHERE status=0";
$result_query = mysqli_query($con, $status_query);
$count = mysqli_num_rows($result_query);
$data = array(
    'notification' => $output,
    'unseen_notification'  => $count
);
echo json_encode($data);
}
?>