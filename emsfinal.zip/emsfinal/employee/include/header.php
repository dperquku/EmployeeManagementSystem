<div class="header-section">
			<!-- top_bg -->

						<div class="top_bg">
						 <ul class="nav navbar-right navbar-top-links">
                 
      </li>
            <li class="dropdown" style="padding-right: 10px;padding-top:4px; ">

                <a class="dropdown-toggle" data-toggle="dropdown" href="#" style="color: red;">


                    <i class="fa fa-user fa-fw" style="color:red; "></i>Welcome : <i><?php echo $login_session; ?></i>
                </a>
               
            </li>
        </ul>
							 <ul class="nav navbar-nav navbar-right">
      <li class="dropdown">
       <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="label label-pill label-danger count" style="border-radius:10px;"></span> <span class="glyphicon glyphicon-envelope" style="font-size:18px;"></span></a>
       <ul class="dropdown-menu"></ul>
      </li>
      <li class="dropdown">
       <a href="#" class="dropdown-toggle-1" data-toggle="dropdown"><span class="label label-pill label-danger count-1" style="border-radius:10px;"></span> <span class="glyphicon glyphicon-bell" style="font-size:18px;"></span></a>
       <ul class="dropdown-menu"></ul></li>
     </ul>
                <script src="js/loadNcal.js"></script> 
                <script src="js/loadM.js"></script> 
								<div class="header_top">
									

										
									</div>
									
										 
                 </div>


								</div>
							
						</div>