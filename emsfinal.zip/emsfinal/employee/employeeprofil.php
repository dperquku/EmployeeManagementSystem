<?php
include('session.php');
    include ('bdd.php');
    if(isset($_GET['empID'])){
        $empID = $_GET['empID'];
    }

    $sql= 'SELECT department.departmentId,employee.empID,department.departmentName,employee.empFirstName,employee.empNO,employee.empLastName, employee.empemail,employee.empbdate,employee.empMobile,employee.empaddress,employee.username,employee.created_date
    FROM department INNER JOIN employee  ON department.departmentId= employee.depEmpId WHERE empID = :empID';

    $query = $bdd->prepare($sql);
    $query->execute(['empID' => $empID]);

    $user = $query->fetch();


?>

<!DOCTYPE HTML>
<html>
<head>
<title>Employe Management System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Gretong Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>

    


        <!-- MetisMenu CSS -->
        <link href="css/metisMenu.min.css" rel="stylesheet">

        <!-- Timeline CSS -->
        <link href="css/timeline.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="css/startmin.css" rel="stylesheet">

        <!-- Morris Charts CSS -->
        <link href="css/morris.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">

<link rel="stylesheet" type="text/css" media="all" href="css/profili.css">
 




<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
<link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />

<!-- //lined-icons -->
<script src="js/jquery-1.10.2.min.js"></script>
   
</head> 
<body>
   <div class="page-container">
   <!--/content-inner-->
  <div class="left-content">
     <div class="inner-content">
    <!-- header-starts -->
      <div class="header-section">
      <!-- top_bg -->
            <div class="top_bg">
             <ul class="nav navbar-right navbar-top-links">
                 
      </li>
            <li class="dropdown" style="padding-right: 10px;padding-top:4px; ">

                <a class="dropdown-toggle" data-toggle="dropdown" href="#" style="color: white;">


                    <i class="fa fa-user fa-fw" style="color:white; "></i>Welcome : <i><?php echo $login_session; ?></i>
                </a>
               
                
            </li>
        </ul>
               <ul class="nav navbar-nav navbar-right">
      <li class="dropdown">
       <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="label label-pill label-danger count" style="border-radius:10px;"></span> <span class="glyphicon glyphicon-envelope" style="font-size:18px;"></span></a>
       <ul class="dropdown-menu"></ul>
      </li>
      <li class="dropdown">
       <a href="#" class="dropdown-toggle-1" data-toggle="dropdown"><span class="label label-pill label-danger count-1" style="border-radius:10px;"></span> <span class="glyphicon glyphicon-bell" style="font-size:18px;"></span></a>
       <ul class="dropdown-menu"></ul></li>
     </ul>
                <script src="js/loadNcal.js"></script> 
                 <script src="js/loadM.js"></script> 
                <div class="header_top">
                  

                    
                  </div>
                    <div class="clearfix">

                     
                 </div>


                </div>
              
            </div>
          <div class="clearfix"></div>
        <!-- /top_bg -->
        </div>
        
      <div class="tdhanat" style="padding: 20px;">
      
  <div id="w">
     <div id="userphoto"><img src="images/avatar.png" alt="default avatar" style="margin-top: -35px;margin-right: 20px;"></div>
    <div id="content" class="clearfix">
     

      <nav id="profiletabs">
        <ul class="clearfix">
          <li><a href="#bio" class="sel">General</a></li>
          <li><a href="#activity">Job</a></li>
          <li><a href="#settings">Login</a></li>
        </ul>
      </nav>
      
      <section id="bio">
        <p>General Details</p>
        
        <p class="setting"><span>First Name <img src="images/edit.png" alt="*Edit*"></span> <?php echo $user['empFirstName']; ?></p>
        
        <p class="setting"><span>Last Name <img src="images/edit.png" alt="*Edit*"></span> <?php echo $user['empLastName']; ?></p>
        
        <p class="setting"><span>Address <img src="images/edit.png" alt="*Edit*"></span> <?php echo $user['empaddress']; ?></p>
        
        <p class="setting"><span>Personal Number <img src="images/edit.png" alt="*Edit*"></span> <?php echo $user['empNO']; ?></p>
        
        <p class="setting"><span>Phone Number <img src="images/edit.png" alt="*Edit*"></span> <?php echo $user['empMobile']; ?></p>

        <p class="setting"><span>Birthday <img src="images/edit.png" alt="*Edit*"></span> <?php echo $user['empbdate']; ?></p>
      </section>
      
      <section id="activity" class="hidden">
         <p>Job Details</p>
        
        
        <p class="setting"><span>Departament <img src="images/edit.png" alt="*Edit*"></span> <?php echo $user['departmentName']; ?></p>
        
        <p class="setting"><span>Start Date <img src="images/edit.png" alt="*Edit*"></span> <?php echo $user['created_date']; ?></p>
        
        
      </section>
      
      
      <section id="settings" class="hidden">
        <p>Login Details</p>
        
        <p class="setting"><span>E-mail Address <img src="images/edit.png" alt="*Edit*"></span> <?php echo $user['empemail']; ?></p>
        
        <p class="setting"><span>Username <img src="images/edit.png" alt="*Edit*"></span> <?php echo $user['username']; ?></p>
        
      </section>
    </div><!-- @end #content -->
  </div><!-- @end #w -->
<script type="text/javascript">
$(function(){
  $('#profiletabs ul li a').on('click', function(e){
    e.preventDefault();
    var newcontent = $(this).attr('href');
    
    $('#profiletabs ul li a').removeClass('sel');
    $(this).addClass('sel');
    
    $('#content section').each(function(){
      if(!$(this).hasClass('hidden')) { $(this).addClass('hidden'); }
    });
    
    $(newcontent).removeClass('hidden');
  });
});
</script>
</div>
        <!--//content-inner-->
      <!--/sidebar-menu-->
        <div class="sidebar-menu">
          <?php include 'include/slider.php'; ?>
                </div>
                <div class="clearfix"></div>    
              </div>
              <script>
              var toggle = true;
                    
              $(".sidebar-icon").click(function() {                
                if (toggle)
                {
                $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
                $("#menu span").css({"position":"absolute"});
                }
                else
                {
                $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
                setTimeout(function() {
                  $("#menu span").css({"position":"relative"});
                }, 400);
                }
                      
                      toggle = !toggle;
                    });
              </script>
<!--js -->
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.min.js"></script>
   <!-- /Bootstrap Core JavaScript -->
   <!-- real-time -->
<script language="javascript" type="text/javascript" src="js/jquery.flot.js"></script>
  
       <script src="js/menu_jquery.js"></script>
</body>
</html>