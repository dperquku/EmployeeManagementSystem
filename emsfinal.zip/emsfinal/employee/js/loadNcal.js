

$(document).ready(function(){
 
// updating the view with notifications using ajax
 
function load_unseen_notification(view = '')
 
{
 
 $.ajax({
 
  url:"include/fetchCal.php",
  method:"POST",
  data:{view:view},
  dataType:"json",
  success:function(data)
 
  {
 
   $('.dropdown-menu').html(data.notification);
 
   if(data.unseen_notification > 0)
   {
    $('.count-1').html(data.unseen_notification);
   }
 
  }
 
 });
 
}
 
load_unseen_notification();
 
// submit form and get new records
 

 
// load new notifications
 
$(document).on('click', '.dropdown-toggle-1', function(){
 
 $('.count').html('');
 
 load_unseen_notification('yes');

 
});
 
setInterval(function(){
 
 load_unseen_notification();;
 
}, 5000);
 
});
