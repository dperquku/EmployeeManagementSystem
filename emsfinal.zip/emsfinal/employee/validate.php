<?php
session_start(); // Starting Session
$error=''; // Variable To Store Error Message
if (isset($_POST['submit'])) {
if (empty($_POST['username']) || empty($_POST['password'])) {
$error = "Username or Password is invalid";
}
else
{

$username=$_POST['username'];
$password=$_POST['password'];

$con = mysqli_connect("localhost", "root", "", "ems");

$username = stripslashes($username);
$password = stripslashes($password);




$query = "Select * from login where password='$password' AND username='$username' AND is_admin='1'";
// $query1 = "SELECT is_admin FROM login WHERE password='$password' AND username='$username";
    
  //  $status=mysqli_query($con,$query1);
   // if (!$status) {
    //printf("Error: %s\n", mysqli_error($con));
    //exit();
//}
    //$Rstatus=mysqli_fetch_array($status);
    
    
$result_query = mysqli_query($con, $query);
$rows = mysqli_num_rows($result_query);
if ($rows==1) {
$_SESSION['login_user']=$username; 
header("location: index.php"); 
} else {
$error = "Username or Password is invalid";
    //header("location: calendar.php"); 
}
mysqli_close($con); // Closing Connection
}
}
?>