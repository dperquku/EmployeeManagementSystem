<?php
	include 'bdd.php';

    if (isset($_GET['manID'])) {
        $manID = $_GET['manID'];
    }
     $query1 = "SELECT * FROM manager WHERE manID= :manID";
    $query1 = $bdd->prepare($query1);

    $query1->execute(['manID' => $manID]);

    $result=$query1->fetch();

   $query2 = "UPDATE login set currentStatus=0 WHERE username='".$result['username']."'";
    $query2 = $bdd->prepare($query2);
    $query2->execute();

    $query = "UPDATE manager set currentStatus=0  WHERE manID= :manID";
    $query = $bdd->prepare($query);

    $query->execute(['manID' => $manID]);


   
    


     header("Location: viewManager.php");
?>
