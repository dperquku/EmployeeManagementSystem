<?php
include('session.php');
include ('bdd.php');
include 'include/connect1.php';
$query = $conn->query('SELECT salary.salID,employee.empFirstName,salary.salBeginDate,salary.salBasicSalary, salary.salGrade,salary.created_date
  FROM employee 
  INNER JOIN salary  ON employee.empID= salary.salEmpID; ');
      $users = $query->fetchAll();

     

?>
<!DOCTYPE HTML>
<html>
<head>
<title>Employe Management System</title>
 <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Gretong Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
 <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">    
    
   


    


 <link href="css/crudstyle.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/r/dt/jq-2.1.4,jszip-2.5.0,pdfmake-0.1.18,dt-1.10.9,af-2.0.0,b-1.0.3,b-colvis-1.0.3,b-html5-1.0.3,b-print-1.0.3,se-1.0.1/datatables.min.css"/>
 
<script type="text/javascript" src="https://cdn.datatables.net/r/dt/jq-2.1.4,jszip-2.5.0,pdfmake-0.1.18,dt-1.10.9,af-2.0.0,b-1.0.3,b-colvis-1.0.3,b-html5-1.0.3,b-print-1.0.3,se-1.0.1/datatables.min.js"></script> 





<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->

<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />

<!-- //lined-icons -->


 


   



      
   
</head> 
<body>
   <div class="page-container">
   <!--/content-inner-->
  <div class="left-content">
     <div class="inner-content">
    <!-- header-starts -->
     <div class="header-section">
      <!-- top_bg -->
            <div class="top_bg">
             <ul class="nav navbar-right navbar-top-links">
                 
      </li>
            <li class="dropdown" style="padding-right: 10px;padding-top:4px; ">

                <a class="dropdown-toggle" data-toggle="dropdown" href="#" style="color: white;">


                    <i class="fa fa-user fa-fw" style="color:white; "></i>Welcome : <i><?php echo $login_session; ?></i>
                </a>
               
                
            </li>
        </ul>
               
                <div class="header_top">
                  

                    
                  </div>
                    <div class="clearfix">

                     
                 </div>


                </div>
              
            </div>
          <div class="clearfix"></div>
        <!-- /top_bg -->
        </div>
        
        
        <!--content-->
      <div class="content">
       
          <div class="col-md-12">
        


            <!-- /widget-header -->
            <div class="widget-content">
              <table id="employee_grid" class="table table-striped table-bordered table-hover" width="100%" cellspacing="5">
                <thead>
                  <tr >
                    <th> Employee Name </th>
                    <th> Begin Date </th>
                    <th> Basic Salary</th>
                    <th> Grand Salary</th>
                    <th > Created Date</th>
                    <th> Edit</th>
                    <th> Delete</th>
                  </tr>
                </thead>
                <tbody>
                

              <?php foreach($users as $user): ?>
                  <tr style="font-size: 11px;color: #444; text-transform: uppercase; ">
                    <td><?php echo $user['empFirstName']; ?></td>
                    <td><?php echo $user['salBeginDate']; ?></td>
                    <td> <?php echo $user['salBasicSalary']; ?> </td>
                     <td> <?php echo $user['salGrade']; ?></td>
                      <td><?php echo $user['created_date']?></td>
                    <td><button type="button" class="btn btn-success" onclick="window.location.href='editSalary.php?salID=<?php echo $user['salID']; ?>'"><i class="fa fa-edit"></i></button></td>
                    <td><button type="button" class="btn btn-danger"  onclick="window.location.href='deletesalary.php?salID=<?php echo $user['salID']; ?>'"><i class="fa fa-trash-o"></button></td>
             <?php endforeach; ?>
                  
              
                   
                
                </tbody>
              </table>
            </div>
    <script type="text/javascript">
$( document ).ready(function() {
$('#employee_grid').DataTable({
     "processing": true,
     "dom": 'lBfrtip',
     "buttons": [
            {
                extend: 'collection',
                text: 'Export',
                buttons: [
                    'copy',
                    'excel',
                    'pdf',
                    'print'
                ]
            }
        ]
      
        });
});
</script>
            <!-- /widget-content --> 
          </div>
          </div>
          </div>
          
      </div>
        <!--//content-inner-->
      <!--/sidebar-menu-->
        <div class="sidebar-menu">
          <?php include 'include/slider.php'; ?>
                </div>
                <div class="clearfix"></div>    
              </div>
              <script>
              var toggle = true;
                    
              $(".sidebar-icon").click(function() {                
                if (toggle)
                {
                $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
                $("#menu span").css({"position":"absolute"});
                }
                else
                {
                $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
                setTimeout(function() {
                  $("#menu span").css({"position":"relative"});
                }, 400);
                }
                      
                      toggle = !toggle;
                    });
              </script>
<!--js -->
<!-- Bootstrap Core JavaScript -->
  
   <!-- /Bootstrap Core JavaScript -->
   <!-- real-time -->

  
       
</body>
</html>