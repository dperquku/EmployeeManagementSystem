<?php
$con = mysqli_connect("localhost", "root", "", "ems");


session_start();// Starting Session
$user_check=$_SESSION['login_user'];
$query="select username from login where username='$user_check'";
$result_query = mysqli_query($con, $query);

$row = mysqli_fetch_assoc($result_query);
$login_session =$row['username'];
if(!isset($login_session)){
mysqli_close($con); // Closing Connection
header('Location: login.php'); // Redirecting To Home Page
}
?>