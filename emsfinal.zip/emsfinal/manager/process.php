<?php 
  $db = mysqli_connect('localhost', 'root', '', 'ems');

  if (isset($_POST['departmentName'])) {
  	$departmentName = $_POST['departmentName'];
  	$sql = "SELECT * FROM department WHERE departmentName='$departmentName'";
  	$results = mysqli_query($db, $sql);
  	if (mysqli_num_rows($results) > 0) {
  	  $message = "Department Name exists";
      echo "<script type='text/javascript'>alert('$message');</script>";
  	}else{
  	  echo 'not_taken';
  	}
  	
  }
  if (isset($_POST['shortName'])) {
  	$shortName = $_POST['shortName'];
  	$sql = "SELECT * FROM department WHERE shortName='$shortName'";
  	$results = mysqli_query($db, $sql);
  	if (mysqli_num_rows($results) > 0) {	
      $message = "Department Short Name exists";
      echo "<script type='text/javascript'>alert('$message');</script>";
  	}else{
  	  echo 'not_taken';
  	}
  
  }
   if (isset($_POST['departmentCode'])) {
    $departmentCode = $_POST['departmentCode'];
    $sql = "SELECT * FROM department WHERE departmentCode='$departmentCode'";
    $results = mysqli_query($db, $sql);
    if (mysqli_num_rows($results) > 0) {
      $message = "Department Code exists";
      echo "<script type='text/javascript'>alert('$message');</script>";
    }else{
      echo 'not_taken';
    }
  
  }
  if (isset($_POST['submit'])) {
  	$departmentName = $_POST['departmentName'];
  	$shortName = $_POST['shortName'];
  	$departmentCode = $_POST['departmentCode'];
  	$sql = "SELECT * FROM department WHERE departmentName='$departmentName'";
  	$results = mysqli_query($db, $sql);
  	if (mysqli_num_rows($results) > 0) {
  	  	$message = "Department  exists";
      echo "<script type='text/javascript'>alert('$message');</script>";
  	
  	}else{
  	  $query = "INSERT INTO department (departmentName, shortName, departmentCode) 
  	       	VALUES ('$departmentName', '$shortName', '$departmentCode')";
  	  $results = mysqli_query($db, $query);
  	 header("Location: viewDepartment.php");
  	}
  }

?>