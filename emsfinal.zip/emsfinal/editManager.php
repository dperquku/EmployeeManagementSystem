<?php
include('session.php');
include 'bdd.php';
include 'include/connect1.php';

$sql = "SELECT departmentName ,departmentId FROM department";
$con = mysqli_connect("localhost", "root", "", "ems");
$result = mysqli_query($con,$sql);
        
        if(isset($_GET['manID'])){
        $manID = $_GET['manID'];
    }
    

   $sql1 = 'SELECT department.departmentId,manager.manID,department.departmentName,manager.manFirstName,manager.manNO,manager.manLastName, manager.manemail,manager.manbdate,manager.manMobile,manager.manaddress 
    FROM department INNER JOIN manager  ON department.departmentId= manager.depManId WHERE manID = :manID';

    $query1 = $bdd->prepare($sql1);
    $query1->execute(['manID' => $manID]);

    $user = $query1->fetch();
  
  if(isset($_POST['submit'])){
      $manFirstName = $_POST['manFirstName'];
            $manLastName = $_POST['manLastName'];
             $manNO = $_POST['manNO'];
            $manemail = $_POST['manemail'];
           
            $manMobile = $_POST['manMobile'];
            $manbdate = $_POST['manbdate'];
            $manaddress = $_POST['manaddress'];
          
            $depManId = $_POST['depManId'];
            

        $sql1 = 'UPDATE manager SET  manFirstName = :manFirstName, manLastName = :manLastName, manNO = :manNO,manemail = :manemail, manMobile = :manMobile,manbdate = :manbdate,manaddress = :manaddress, depManId=:depManId WHERE manID = :manID ';
        $query2 = $conn->prepare($sql1);

        $query2->bindParam('manFirstName', $manFirstName);
    $query2->bindParam('manLastName', $manLastName);
    $query2->bindParam('manNO', $manNO);
        $query2->bindParam('manemail', $manemail);
          $query2->bindParam('manMobile', $manMobile);
        $query2->bindParam('manbdate', $manbdate);
        $query2->bindParam('manaddress', $manaddress);
        
        $query2->bindParam('depManId', $depManId);
        $query2->bindParam('manID', $manID);
          
        if( $query2->execute()) {
                                                $message = "Thank You for your Feedback!  ";
                                                    echo "$message";
                                                     header("Location: viewManager.php");
                                            } else {
                                                $message = "A problem occurred creating your account";
                                                 echo "$message";
                                            }
                                                
                                                
                                               
    }

     

?>

<!DOCTYPE HTML>
<html>
<head>
<title>Employe Management System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Gretong Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
<link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />

<!-- //lined-icons -->
<link rel="stylesheet" href="css/emp.css" />
<link rel="stylesheet" href="css/style1234.css" />
   
</head> 
<body>
   <div class="page-container">
   <!--/content-inner-->
  <div class="left-content">
     <div class="inner-content">
    <!-- header-starts -->
      <div class="header-section">
      <!-- top_bg -->
            <div class="top_bg">
             <ul class="nav navbar-right navbar-top-links">
                 
      </li>
            <li class="dropdown" style="padding-right: 10px;padding-top:4px; ">

                <a class="dropdown-toggle" data-toggle="dropdown" href="#" style="color: white;">


                    <i class="fa fa-user fa-fw" style="color:white; "></i>Welcome : <i><?php echo $login_session; ?></i>
                </a>
               
                
            </li>
        </ul>
                <div class="header_top">
                  

                    
                  </div>
                    <div class="clearfix">

                     
                 </div>


                </div>
              
            </div>
          <div class="clearfix"></div>
        <!-- /top_bg -->
        </div>
        
        
        <!--content-->
      <div class="content">
      <div>
<h1 ><i class="menu-icon fa fa-pencil" style="padding-right: 10px; padding-left: 20px;"></i> Edit Manager</h1></div>
 
<div class="employee" >


      <div class="empReg">
    <form  method="POST" style="margin-right:60px;" >
      <div class="col-sm-3">
         
          <div class="inputi">
            <label for="manNO" >Personal Number <span class="req">*</span> </label>
            <input type="text" name="manNO" value="<?php echo $user['manNO']; ?>"  required />      
          </div>
          <div class="inputi">
            <label for="manFirstName" >First Name <span class="req">*</span> </label>
            <input type="text" name="manFirstName" value="<?php echo $user['manFirstName']; ?>" required />      
          </div>
           <div class="inputi">
            <label for="manLastName">Last Name <span class="req">*</span> </label>
            <input type="text" name="manLastName" value="<?php echo $user['manLastName']; ?>"  required />      
          </div>
           <div class="inputi">
            <label for="manemail">Email <span class="req">*</span> </label>
            <input type="text" name="manemail" value="<?php echo $user['manemail']; ?>"  required />      
          </div>
          

          <input class="btn btn-submit" type="submit" name="submit" value="Save" style="margin-top: 10px;" />
      </div>
   <div class="col-sm-3">
         
        
           <div class="inputi">
            <label for="manbdate">Date of Birth <span class="req">*</span> </label>
            <input type="date" name="manbdate" style="width: 205px; height: 40px;" value="<?php echo $user['manbdate']; ?>"  required />      
          </div>
           <div class="inputi">
            <label for="manMobile">Phone Number <span class="req">*</span> </label>
            <input type="text" name="manMobile" value="<?php echo $user['manMobile']; ?>"  required />      
          </div>
          

      </div>
         <div class="col-sm-3">
         
         
          <div class="inputi">
            <label for="manaddress">Address<span class="req">*</span> </label>
            <input type="text" name="manaddress" value="<?php echo $user['manaddress']; ?>"  required />      
          </div>
          
          <div class="inputi1">
                 <label for="department" style="padding-top: 10px; ">Department<span class="req">*</span> </label>
              <?php  echo "<select name='depManId'  style='padding-right:40px; width:205px; height:40px; border: 1px solid #ccc;color: #555;' required >";
                 echo "<option value='" . $user['departmentId'] ."'>".$user['departmentName']."</option>";
        while ($row = mysqli_fetch_array($result)) {
          echo "<option value='" . $row['departmentId'] ."'>" . $row['departmentName'] ."</option>";
        }
        echo "</select>"; ?>      
          </div>
      </div>
         
       
        
       
     
    </form> 
  </div>
    
   </div>
  </div>
    
      <!--content-->
    </div>
</div>
        <!--//content-inner-->
      <!--/sidebar-menu-->
        <div class="sidebar-menu">
          <?php include 'include/slider.php'; ?>
                </div>
                <div class="clearfix"></div>    
              </div>
              <script>
              var toggle = true;
                    
              $(".sidebar-icon").click(function() {                
                if (toggle)
                {
                $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
                $("#menu span").css({"position":"absolute"});
                }
                else
                {
                $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
                setTimeout(function() {
                  $("#menu span").css({"position":"relative"});
                }, 400);
                }
                      
                      toggle = !toggle;
                    });
              </script>
<!--js -->


<!-- Bootstrap Core JavaScript -->
 
   <!-- /Bootstrap Core JavaScript -->
   <!-- real-time -->

       

 <!-- time picker -->
        <script src="http://code.jquery.com/jquery-1.12.4.min.js"></script>
        
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
      <link rel="stylesheet" href="css/clockface.css">    
        <script src="js/clockface.js"></script>

<script id="js-t1">
$(function(){
    $('#t1').clockface();
    $('#t2').clockface();  
});
</script>

</body>
</html>