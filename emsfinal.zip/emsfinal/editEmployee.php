<?php
include('session.php');
include 'bdd.php';
include 'include/connect1.php';

$sql = "SELECT departmentName ,departmentId FROM department";
$con = mysqli_connect("localhost", "root", "", "ems");
$result = mysqli_query($con,$sql);

        if(isset($_GET['empID'])){
        $empID = $_GET['empID'];
    }
    

    $sql1 = 'SELECT department.departmentId,employee.empID,department.departmentName,employee.empFirstName,employee.empNO,employee.empLastName, employee.empemail,employee.empbdate,employee.empMobile,employee.empaddress 
    FROM department INNER JOIN employee  ON department.departmentId= employee.depEmpId WHERE empID = :empID';

    
    $query1 = $bdd->prepare($sql1);
    $query1->execute(['empID' => $empID]);


    $user = $query1->fetch();
  
  if(isset($_POST['submit'])){
      $empFirstName = $_POST['empFirstName'];
            $empLastName = $_POST['empLastName'];
             $empNO = $_POST['empNO'];
            $empemail = $_POST['empemail'];
           
            $empMobile = $_POST['empMobile'];
            $empbdate = $_POST['empbdate'];
            $empaddress = $_POST['empaddress'];
          
            $depEmpId = $_POST['depEmpId'];
            

        $sql1 = 'UPDATE employee SET  empFirstName = :empFirstName, empLastName = :empLastName, empNO = :empNO,empemail = :empemail, empMobile = :empMobile,empbdate = :empbdate,empaddress = :empaddress, depEmpId=:depEmpId WHERE empID = :empID ';
        $query2 = $conn->prepare($sql1);

        $query2->bindParam('empFirstName', $empFirstName);
    $query2->bindParam('empLastName', $empLastName);
    $query2->bindParam('empNO', $empNO);
        $query2->bindParam('empemail', $empemail);
          $query2->bindParam('empMobile', $empMobile);
        $query2->bindParam('empbdate', $empbdate);
        $query2->bindParam('empaddress', $empaddress);
        
        $query2->bindParam('depEmpId', $depEmpId);
        $query2->bindParam('empID', $empID);
          
        if( $query2->execute()) {
                                                $message = "Thank You for your Feedback!  ";
                                                    echo "$message";
                                                     header("Location: viewEmployee.php");
                                            } else {
                                                $message = "A problem occurred creating your account";
                                                 echo "$message";
                                            }
                                                
                                                
                                               
    }

     

?>

<!DOCTYPE HTML>
<html>
<head>
<title>Employe Management System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Gretong Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
<link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />

<!-- //lined-icons -->
<link rel="stylesheet" href="css/emp.css" />
<link rel="stylesheet" href="css/style1234.css" />
   
</head> 
<body>
   <div class="page-container">
   <!--/content-inner-->
  <div class="left-content">
     <div class="inner-content">
    <!-- header-starts -->
      <div class="header-section">
      <!-- top_bg -->
            <div class="top_bg">
             <ul class="nav navbar-right navbar-top-links">
                 
      </li>
            <li class="dropdown" style="padding-right: 10px;padding-top:4px; ">

                <a class="dropdown-toggle" data-toggle="dropdown" href="#" style="color: white;">


                    <i class="fa fa-user fa-fw" style="color:white; "></i>Welcome : <i><?php echo $login_session; ?></i>
                </a>
               
                
            </li>
        </ul>
              
                <div class="header_top">
                  

                    
                  </div>
                    <div class="clearfix">

                     
                 </div>


                </div>
              
            </div>
          <div class="clearfix"></div>
        <!-- /top_bg -->
        </div>
        
        
        <!--content-->
      <div class="content">
      <div>
<h1 ><i class="menu-icon fa fa-pencil" style="padding-right: 10px; padding-left: 20px;"></i> Edit Employee</h1></div>
 
<div class="employee" >


      <div class="empReg">
    <form  method="POST" style="margin-right:60px;" >
      <div class="col-sm-3">
         
          <div class="inputi">
            <label for="empNO" >Personal Number <span class="req">*</span> </label>
            <input type="text" name="empNO" value="<?php echo $user['empNO']; ?>"  required />      
          </div>
          <div class="inputi">
            <label for="empFirstName" >First Name <span class="req">*</span> </label>
            <input type="text" name="empFirstName" value="<?php echo $user['empFirstName']; ?>" required />      
          </div>
           <div class="inputi">
            <label for="empLastName">Last Name <span class="req">*</span> </label>
            <input type="text" name="empLastName" value="<?php echo $user['empLastName']; ?>"  required />      
          </div>
           <div class="inputi">
            <label for="empemail">Email <span class="req">*</span> </label>
            <input type="text" name="empemail" value="<?php echo $user['empemail']; ?>"  required />      
          </div>
          

          <input class="btn btn-submit" type="submit" name="submit" value="Save" style="margin-top: 10px;" />
      </div>
   <div class="col-sm-3">
         
        
           <div class="inputi">
            <label for="empbdate">Date of Birth <span class="req">*</span> </label>
            <input type="date" name="empbdate" style="width: 205px; height: 40px;" value="<?php echo $user['empbdate']; ?>"  required />      
          </div>
           <div class="inputi">
            <label for="empMobile">Phone Number <span class="req">*</span> </label>
            <input type="text" name="empMobile" value="<?php echo $user['empMobile']; ?>"  required />      
          </div>
          

      </div>
         <div class="col-sm-3">
         
         
          <div class="inputi">
            <label for="empaddress">Address<span class="req">*</span> </label>
            <input type="text" name="empaddress" value="<?php echo $user['empaddress']; ?>"  required />      
          </div>
          
          <div class="inputi1">
                 <label for="department" style="padding-top: 10px; ">Department<span class="req">*</span> </label>
              <?php  echo "<select name='depEmpId'  style='padding-right:40px; width:205px; height:40px; border: 1px solid #ccc;color: #555;' required >";
                echo "<option value='" . $user['departmentId'] ."'>".$user['departmentName']."</option>"; 
        while ($row = mysqli_fetch_array($result)) {
          echo "<option value='" . $row['departmentId'] ."'>" . $row['departmentName'] ."</option>";
        }
        echo "</select>"; ?>      
          </div>
      </div>
         
       
        
       
     
    </form> 
  </div>
    
   </div>
  </div>
    
      <!--content-->
    </div>
</div>
        <!--//content-inner-->
      <!--/sidebar-menu-->
        <div class="sidebar-menu">
          <?php include 'include/slider.php'; ?>
                </div>
                <div class="clearfix"></div>    
              </div>
              <script>
              var toggle = true;
                    
              $(".sidebar-icon").click(function() {                
                if (toggle)
                {
                $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
                $("#menu span").css({"position":"absolute"});
                }
                else
                {
                $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
                setTimeout(function() {
                  $("#menu span").css({"position":"relative"});
                }, 400);
                }
                      
                      toggle = !toggle;
                    });
              </script>
<!--js -->


<!-- Bootstrap Core JavaScript -->
 
   <!-- /Bootstrap Core JavaScript -->
   <!-- real-time -->

       

 <!-- time picker -->
        <script src="http://code.jquery.com/jquery-1.12.4.min.js"></script>
        
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
      <link rel="stylesheet" href="css/clockface.css">    
        <script src="js/clockface.js"></script>

<script id="js-t1">
$(function(){
    $('#t1').clockface();
    $('#t2').clockface();  
});
</script>

</body>
</html>