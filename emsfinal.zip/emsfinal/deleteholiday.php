<?php
	include 'bdd.php';

    if (isset($_GET['holID'])) {
        $holID = $_GET['holID'];
    }

    $query = "DELETE FROM holiday WHERE holID= :holID";
    $query = $bdd->prepare($query);

    $query->execute(['holID' => $holID]);

     header("Location: viewHoliday.php");
?>
