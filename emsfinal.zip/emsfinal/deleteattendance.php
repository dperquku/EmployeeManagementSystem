<?php
	include 'bdd.php';

    if (isset($_GET['attId'])) {
        $attId = $_GET['attId'];
    }

    $query = "DELETE FROM attendance WHERE attId= :attId";
    $query = $bdd->prepare($query);

    $query->execute(['attId' => $attId]);

     header("Location: viewAttendance.php");
?>
