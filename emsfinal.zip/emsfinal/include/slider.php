<header class="logo1">
						<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
						<a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> 
					</header>
						<div style="border-top:1px ridge rgba(255, 255, 255, 0.15)"></div>
                           <div class="menu">
									<ul id="menu" >
										<li><a href="index.php"><i class="fa fa-tachometer"></i> <span>Dashboard</span></a></li>
										 <li id="menu-academico" ><a href="#"><i class="fa fa-user"></i> <span> Employee</span> <span class="fa fa-angle-right" style="float: right"></span></a>
										   <ul id="menu-academico-sub" >
										   <li  ><a href="employeeRegister.php"><i class="fa fa-plus-square"></i>Employee Register</a></li>
											<li  ><a href="viewEmployee.php"><i class="fa fa-eye"></i>View Employee</a></li>

											
										  </ul>
										</li>
										<li id="menu-academico" ><a href="#"> <i class="fa fa-briefcase"></i><span> Manager</span> <span class="fa fa-angle-right" style="float: right"></span></a>
										   <ul id="menu-academico-sub" >
										   <li  ><a href="managerRegister.php"><i class="fa fa-plus-square"> </i>Manager Register</a></li>
											<li  ><a href="viewManager.php"> <i class="fa fa-eye"></i> View Manager </a></li>
											
										  </ul>
										</li>
											<li id="menu-academico" ><a href="#"><i class="fa fa-building-o fa-5x"></i><span> Department</span> <span class="fa fa-angle-right" style="float: right"></span></a>
										   <ul id="menu-academico-sub" >
										   <li  ><a href="departmentRegister.php"><i class="fa fa-plus-square"></i> Department Register</a></li>
											<li  ><a href="viewDepartment.php"> <i class="fa fa-eye"></i> View Departments </a></li>
											
										  </ul>
										</li>
										<li id="menu-academico" ><a href="#"><i class="fa fa-calendar-check-o"></i><span> Shift Allocation</span> <span class="fa fa-angle-right" style="float: right"></span></a>
										   <ul id="menu-academico-sub" >
										   <li  ><a href="shiftRegister.php"><i class="fa fa-plus-square"> </i>Shift Register</a></li>
											<li  ><a href="viewShift.php"><i class="fa fa-eye"></i> View Shift </a></li>
											
										  </ul>
										</li>
										<li id="menu-academico" ><a href="#"><i class="fa fa-calendar-check-o"></i><span> Shift Attendance</span> <span class="fa fa-angle-right" style="float: right"></span></a>
										   <ul id="menu-academico-sub" >
										   <li  ><a href="shiftAttendance.php"><i class="fa fa-plus-square"></i> Shift Attendance Register</a></li>
											<li  ><a href="ViewShiftAttendance.php"><i class="fa fa-eye"></i> View Shift Attendance</a></li>
											
										  </ul>
										</li>
										<li id="menu-academico" ><a href="#"><i class="fa fa-calendar-plus-o"></i> <span>Attendance</span> <span class="fa fa-angle-right" style="float: right"></span></a>
										   <ul id="menu-academico-sub" >
										   <li  ><a href="attendanceRegister.php"><i class="fa fa-plus-square"></i> Attendance Register</a></li>
											<li  ><a href="viewAttendance.php"><i class="fa fa-eye"></i> View  Attendance</a></li>
											
										  </ul>
										</li>
										<li id="menu-academico" ><a href="#"><i class="fa fa-credit-card"></i> <span> Salary</span> <span class="fa fa-angle-right" style="float: right"></span></a>
										   <ul id="menu-academico-sub" >
										   <li  ><a href="SalaryRegister.php"><i class="fa fa-plus-square"></i> Salary Register</a></li>
											<li  ><a href="viewSalary.php"><i class="fa fa-eye"></i> View Salary </a></li>
											
										  </ul>
										</li>
										<li id="menu-academico" ><a href="#"><i class="fa fa-calendar-times-o"></i><span> Holiday</span> <span class="fa fa-angle-right" style="float: right"></span></a>
										   <ul id="menu-academico-sub" >
										   <li  ><a href="holidayRegister.php"><i class="fa fa-plus-square"></i> Holiday Register</a></li>
											<li  ><a href="viewHoliday.php"><i class="fa fa-eye"></i> View Holiday</a></li>
											
										  </ul>
										</li>
										<li><a href="inbox.php"><i class="fa fa-envelope"></i> <span>Inbox</span></a></li>
										<li><a href="calendar.php"><i class="fa fa-calendar"></i> <span>Calendar</span></a></li>
										<li><a href="logout.php" ><i class="fa fa-sign-out fa-fw" ></i><span> Logout</span></a></li>
										 
								  </ul>
								</div>