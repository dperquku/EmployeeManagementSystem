<?php
include('session.php');
include 'bdd.php';
include 'include/connect1.php';




        if(isset($_GET['holID'])){
        $holID = $_GET['holID'];
    }
    

    $sql1 = 'SELECT * FROM holiday WHERE holID = :holID';
    $query1 = $bdd->prepare($sql1);
    $query1->execute(['holID' => $holID]);


    $user = $query1->fetch();
  
  if(isset($_POST['submit'])){
     
                                               
      $holName = $_POST['holName'];
      $holDate = $_POST['holDate'];
      $holDescription =$_POST['holDescription'];  
  

        $sql1 = 'UPDATE holiday SET  holName = :holName, holDate = :holDate, holDescription = :holDescription WHERE holID = :holID ';
        $query2 = $conn->prepare($sql1);

        $query2->bindParam('holID', $holID);
    $query2->bindParam('holName', $holName);
    $query2->bindParam('holDate', $holDate);
        $query2->bindParam('holDescription', $holDescription);
        
        if( $query2->execute()) {
                                                $message = "Thank You for your Feedback!  ";
                                                    echo "$message";
                                                     header("Location: viewHoliday.php");
                                            } else {
                                                $message = "A problem occurred creating your account";
                                                 echo "$message";
                                            }
                                                
                                                
                                               
    }

     

?>

<!DOCTYPE HTML>
<html>
<head>
<title>Employe Management System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Gretong Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
<link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />

<!-- //lined-icons -->
<link rel="stylesheet" href="css/emp.css" />
<link rel="stylesheet" href="css/style1234.css" />
   
</head> 
<body>
   <div class="page-container">
   <!--/content-inner-->
  <div class="left-content">
     <div class="inner-content">
    <!-- header-starts -->
      <div class="header-section">
      <!-- top_bg -->
            <div class="top_bg">
             <ul class="nav navbar-right navbar-top-links">
                 
      </li>
            <li class="dropdown" style="padding-right: 10px;padding-top:4px; ">

                <a class="dropdown-toggle" data-toggle="dropdown" href="#" style="color: white;">


                    <i class="fa fa-user fa-fw" style="color:white; "></i>Welcome : <i><?php echo $login_session; ?></i>
                </a>
               
                
            </li>
        </ul>
               
                <div class="header_top">
                  

                    
                  </div>
                    <div class="clearfix">

                     
                 </div>


                </div>
              
            </div>
          <div class="clearfix"></div>
        <!-- /top_bg -->
        </div>
        
        
        <!--content-->
      <div class="content">
      <div>
<h1 ><i class="menu-icon fa fa-pencil" style="padding-right: 10px; padding-left: 20px;"></i> Edit Holiday</h1></div>
 
<div class="container1" >
<?php $startA = explode(" ", $user['holDate']);
               
                if($startA[1] == '00:00:00'){
                  $startA = $startA[0];
                }else{
                  $startA = $user['holDate'];}?>

     <div class="row body">
      <form  method="POST" style="margin-right:60px;">
      <ul>
        
        <li>
          <p class="left">
          <label for="last_name">Holiday Name: </label>
          <input type="text" name="holName" value="<?php echo $user['holName']; ?>" required /> 
          </p>
          <p class="pull-right">
            <label for="last_name">Holiday  Date </label>
            <input type="date" name="holDate" id="datepicker" value="<?php echo $startA; ?>" required />      
          </p>
        </li>
        
        <li>
          <p>
            <label for="email">Description <span class="req">*</span></label>
            <input type="text" name="holDescription" value="<?php echo $user['holDescription']; ?>" required  />
          </p>
        
        </li>        
       
        
        <li>
          <input class="btn btn-submit" type="submit" name="submit" value="Save" />
        
        </li>
        
      </ul>
    </form> 
  </div>
    
   </div>
  </div>
    
      <!--content-->
    </div>
</div>
        <!--//content-inner-->
      <!--/sidebar-menu-->
        <div class="sidebar-menu">
          <?php include 'include/slider.php'; ?>
                </div>
                <div class="clearfix"></div>    
              </div>
              <script>
              var toggle = true;
                    
              $(".sidebar-icon").click(function() {                
                if (toggle)
                {
                $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
                $("#menu span").css({"position":"absolute"});
                }
                else
                {
                $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
                setTimeout(function() {
                  $("#menu span").css({"position":"relative"});
                }, 400);
                }
                      
                      toggle = !toggle;
                    });
              </script>
<!--js -->


<!-- Bootstrap Core JavaScript -->
 
   <!-- /Bootstrap Core JavaScript -->
   <!-- real-time -->

       

 <!-- time picker -->
        <script src="http://code.jquery.com/jquery-1.12.4.min.js"></script>
        
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
      <link rel="stylesheet" href="css/clockface.css">    
        <script src="js/clockface.js"></script>

<script id="js-t1">
$(function(){
    $('#t1').clockface();
    $('#t2').clockface();  
});
</script>

</body>
</html>