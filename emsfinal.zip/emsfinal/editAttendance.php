<?php
include('session.php');
include 'bdd.php';
include 'include/connect1.php';


$sql = "SELECT empFirstName ,empID FROM employee";
$con = mysqli_connect("localhost", "root", "", "ems");
$result = mysqli_query($con,$sql);

        if(isset($_GET['attId'])){
        $attId = $_GET['attId'];
    }
    

    $sql1 = 'SELECT employee.empID,attendance.attEmpID,employee.empFirstName,attendance.attDate, attendance.attonTime,attendance.attoffTime
  FROM employee 
  INNER JOIN attendance  ON employee.empID= attendance.attEmpID WHERE attId = :attId';
    $query1 = $bdd->prepare($sql1);
    $query1->execute(['attId' => $attId]);


    $user = $query1->fetch();
  
  if(isset($_POST['submit'])){
     
            $attEmpID = $_POST['attEmpID'];
             $attDate = $_POST['attDate'];
            $attonTime = $_POST['attonTime'];
           
            $attoffTime = $_POST['attoffTime'];
            

        $sql1 = 'UPDATE attendance SET  attEmpID = :attEmpID, attDate = :attDate, attonTime = :attonTime,attoffTime = :attoffTime WHERE attId = :attId ';
        $query2 = $conn->prepare($sql1);

        $query2->bindParam('attEmpID', $attEmpID);
    $query2->bindParam('attDate', $attDate);
    $query2->bindParam('attonTime', $attonTime);
        $query2->bindParam('attoffTime', $attoffTime);
          $query2->bindParam('attId', $attId);
      
        if( $query2->execute()) {
                                                $message = "Thank You for your Feedback!  ";
                                                    echo "$message";
                                                     header("Location: viewAttendance.php");
                                            } else {
                                                $message = "A problem occurred creating your account";
                                                 echo "$message";
                                            }
                                                
                                                
                                               
    }

     

?>

<!DOCTYPE HTML>
<html>
<head>
<title>Employe Management System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Gretong Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
<link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />

<!-- //lined-icons -->
<link rel="stylesheet" href="css/emp.css" />
<link rel="stylesheet" href="css/style1234.css" />
   
</head> 
<body>
   <div class="page-container">
   <!--/content-inner-->
  <div class="left-content">
     <div class="inner-content">
    <!-- header-starts -->
      <div class="header-section">
      <!-- top_bg -->
            <div class="top_bg">
             <ul class="nav navbar-right navbar-top-links">
                 
      </li>
            <li class="dropdown" style="padding-right: 10px;padding-top:4px; ">

                <a class="dropdown-toggle" data-toggle="dropdown" href="#" style="color: white;">


                    <i class="fa fa-user fa-fw" style="color:white; "></i>Welcome : <i><?php echo $login_session; ?></i>
                </a>
               
                
            </li>
        </ul>
               
                <div class="header_top">
                  

                    
                  </div>
                    <div class="clearfix">

                     
                 </div>


                </div>
              
            </div>
          <div class="clearfix"></div>
        <!-- /top_bg -->
        </div>
        
        
        <!--content-->
      <div class="content">
      <div>
<h1 ><i class="menu-icon fa fa-pencil" style="padding-right: 10px; padding-left: 20px;"></i> Edit Attendance</h1></div>
 
<div class="container1" >
<?php $startA = explode(" ", $user['attDate']);
               
                if($startA[1] == '00:00:00'){
                  $startA = $startA[0];
                }else{
                  $startA = $user['attDate'];}?>

      <div class="row body">
    <form  method="POST" style="margin-right:60px;" >
      <ul>
        
        <li>
          <p class="left">
          <label for="last_name">Select Employee </label>
          <?php  echo "<select name='attEmpID' style='padding-right:40px;' required >";
               echo "<option value='" . $user['empID'] ."'>".$user['empFirstName']."</option>";  
while ($row = mysqli_fetch_array($result)) {
    echo "<option value='" . $row['empID'] ."'>" . $row['empFirstName'] ."</option>";
}
echo "</select>"; ?>
          </p>
          <p class="pull-right">
            <label for="last_name">Date <span class="req">*</span> </label>
            <input type="date" name="attDate"  value="<?php echo $startA ;?>"  id="datepicker" required />      
          </p>
        </li>
        
        <li>
          <p>
            <label for="email">On Time <span class="req">*</span></label>
           <input type="text" id="t1" value="<?php echo $user['attonTime']; ?>" data-format="hh:mm A"  name="attonTime">
          </p>
          <p class="pull-right" style="margin-left: 30px;" >
            <label for="last_name">Off Time <span class="req">*</span></label>
         <input type="text" id="t2" value="<?php echo $user['attoffTime']; ?>" data-format="hh:mm A"  name="attoffTime">
          </p>
        </li>        
       
        
        <li>
          <input class="btn btn-submit" type="submit" name="submit" value="Save" />
        
        </li>
        
      </ul>
    </form> 
  </div>
    
   </div>
  </div>
    
      <!--content-->
    </div>
</div>
        <!--//content-inner-->
      <!--/sidebar-menu-->
        <div class="sidebar-menu">
          <?php include 'include/slider.php'; ?>
                </div>
                <div class="clearfix"></div>    
              </div>
              <script>
              var toggle = true;
                    
              $(".sidebar-icon").click(function() {                
                if (toggle)
                {
                $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
                $("#menu span").css({"position":"absolute"});
                }
                else
                {
                $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
                setTimeout(function() {
                  $("#menu span").css({"position":"relative"});
                }, 400);
                }
                      
                      toggle = !toggle;
                    });
              </script>
<!--js -->


<!-- Bootstrap Core JavaScript -->
 
   <!-- /Bootstrap Core JavaScript -->
   <!-- real-time -->

       

 <!-- time picker -->
        <script src="http://code.jquery.com/jquery-1.12.4.min.js"></script>
        
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
      <link rel="stylesheet" href="css/clockface.css">    
        <script src="js/clockface.js"></script>

<script id="js-t1">
$(function(){
    $('#t1').clockface();
    $('#t2').clockface();  
});
</script>

</body>
</html>