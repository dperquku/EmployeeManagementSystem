
<?php
include('validate.php'); // Includes Login Script


?>

<!DOCTYPE html>
<html>
<head>
  <title>Login EMS</title>
    <link rel="stylesheet" href="css/stylelogin.css" type="text/css" />
</head>



<body class="align">

  <div class="grid">

    <div id="login">

      <h2> <span class="fontawesome-lock"></span>LogIn</h2>

      <form action="#" method="POST">

        <fieldset>

          <p><label for="name">Name</label></p>
          <p><input type="name" id="name" placeholder="username" name="username"></p>

          <p><label for="password">Password</label></p>
          <p><input type="password" id="password" placeholder="password" name="password"></p>
          <span style="color:red;"><?php echo $error; ?></span>
          <p><input type="submit" value="Sign In" name="submit"></p>
          
        </fieldset>

      </form>

    </div> <!-- end login -->

  </div>

</body>	

</html>