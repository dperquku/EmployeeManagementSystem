<?php
include('session.php');
include ('bdd.php');
if(isset($_GET['empID'])){
        $empID = $_GET['empID'];
    }

     $sql1 = 'SELECT COUNT(empID) as numri,employee.empFirstName,employee.empLastName,employee.empemail, employee.empID FROM employee 
  INNER JOIN shift_allocation  ON employee.empID= shift_allocation.aloEmpID WHERE empID=:empID';
    $query1 = $bdd->prepare($sql1);
  $query1->execute(['empID' => $empID]);
    $event = $query1->fetchAll();
?>

<!DOCTYPE HTML>
<html>
<head>
<title>Employe Management System</title>
 <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Gretong Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
 <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">    
    
   


    


 <link href="css/crudstyle.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/r/dt/jq-2.1.4,jszip-2.5.0,pdfmake-0.1.18,dt-1.10.9,af-2.0.0,b-1.0.3,b-colvis-1.0.3,b-html5-1.0.3,b-print-1.0.3,se-1.0.1/datatables.min.css"/>
 
<script type="text/javascript" src="https://cdn.datatables.net/r/dt/jq-2.1.4,jszip-2.5.0,pdfmake-0.1.18,dt-1.10.9,af-2.0.0,b-1.0.3,b-colvis-1.0.3,b-html5-1.0.3,b-print-1.0.3,se-1.0.1/datatables.min.js"></script> 





<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->

<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />

<!-- //lined-icons -->


 

   



      
   
</head> 
<body>
   <div class="page-container">
   <!--/content-inner-->
  <div class="left-content">
     <div class="inner-content">
    <!-- header-starts -->
     <div class="header-section">
      <!-- top_bg -->
            <div class="top_bg">
             <ul class="nav navbar-right navbar-top-links">
                 
      </li>
            <li class="dropdown" style="padding-right: 10px;padding-top:4px; ">

                <a class="dropdown-toggle" data-toggle="dropdown" href="#" style="color: white;">


                    <i class="fa fa-user fa-fw" style="color:white; "></i>Welcome : <i><?php echo $login_session; ?></i>
                </a>
               
                
            </li>
        </ul>
               
                <div class="header_top">
                  

                    
                  </div>
                    <div class="clearfix">

                     
                 </div>


                </div>
              
            </div>
          <div class="clearfix"></div>
        <!-- /top_bg -->
        </div>
        
        
        <!--content-->
      <div class="content">
       
          <div class="col-md-12">
        


            <!-- /widget-header -->
            <div class="widget-content">
              <table id="employee_grid" class="table table-striped table-bordered table-hover" width="100%" cellspacing="5">
                <thead>
                  <tr >
                    <th> Employee ID</th>

                    <th> First Name</th>
                    <th> Last Name</th>
                    <th> Email</th>

                    <th> Times used</th>
                  
                   
                  </tr>
                </thead>
                <tbody>
                

          <?php foreach($event as $user): ?>
                  <tr style="font-size: 11px;color: #444; text-transform: uppercase; ">
                    <td><?php echo $user['empID']; ?></td>
                    <td><?php echo $user['empFirstName']; ?></td>
                    <td><?php echo $user['empLastName']; ?></td>
                    <td><?php echo $user['empemail']; ?></td>
                                 <td><?php echo $user['numri']; ?>      <b style="color:DodgerBlue;"><i>Time(s) used Shift Allocation</i></b></td>
                                

                   
                   
                  </tr>
             <?php endforeach; ?>
                  
              
                   
                
                </tbody>
              </table>
            </div>
    <script type="text/javascript">
$( document ).ready(function() {
$('#employee_grid').DataTable({
     "processing": true,
     "dom": 'lBfrtip',
     "buttons": [
            {
                extend: 'collection',
                text: 'Export',
                buttons: [
                    'copy',
                    'excel',
                    'pdf',
                    'print'
                ]
            }
        ]
      
        });
});
</script>
            <!-- /widget-content --> 
          </div>
          </div>
          </div>
          
      </div>
        <!--//content-inner-->
      <!--/sidebar-menu-->
        <div class="sidebar-menu">
          <?php include 'include/slider.php'; ?>
                </div>
                <div class="clearfix"></div>    
              </div>
              <script>
              var toggle = true;
                    
              $(".sidebar-icon").click(function() {                
                if (toggle)
                {
                $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
                $("#menu span").css({"position":"absolute"});
                }
                else
                {
                $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
                setTimeout(function() {
                  $("#menu span").css({"position":"relative"});
                }, 400);
                }
                      
                      toggle = !toggle;
                    });
              </script>
<!--js -->
<!-- Bootstrap Core JavaScript -->
  
   <!-- /Bootstrap Core JavaScript -->
   <!-- real-time -->

  
       
</body>
</html>